//To be completed:
// Student id:  
// Student name:
// date:

#include <iostream>
#include <mutex>
#include <thread>

#define N 20
#define S 10
#define MAX_WALKERS_PER_LOCATION 3
#define MAX_WALKERS_PER_EDGE 4
#define VERTEX_SLEEP_TIME 1
#define EDGE_SLEEP_TIME 1

typedef struct _Walker
{
    int currentX, currentY, finalX, finalY;
    bool hasArrived;
    void Init() 
    {
        currentX = rand() % S;
        currentY = rand() % S;
        finalX = rand() % S;
        finalY = rand() % S;
        hasArrived = false;
    }
    bool RandomWalk(int& newX, int& newY, int& edgeIndex)
        //This function returns a new location and a unique index for the edge to be crossed
    {
        int direction = rand() % 2; //pick up one direction out of 4 randomly;
        int sign = (rand() % 2) ? +1 : -1; //if direction is even then going the negative way else going the positive way. Use the C ternary operator ?: equivalent to if then else section
        if (direction == 1)  /*Processing a vertical direction*/
        {
            newX = currentX;
            newY = currentY + sign;
            edgeIndex = (S * (S - 1)) + newX * (S - 1) + newY + (sign > 0 ? -1 : 0);
        }
        else /*Processing a horizontal direction*/
        {
            newX = currentX + sign;
            newY = currentY;
            edgeIndex = newY * (S - 1) + newX + (sign > 0 ? -1 : 0);
        }
        if (newX < 0 || newX >= S || newY < 0 || newY >= S)
            return false; //out of bound. The walker is out of the grid so returning false and we will try later on.
        return true;
    }
} Walker;

int originalGridCount[S][S];  //used to make sure the number of walkers per location is within the limits. Do not modify!
int finalGridCount[S][S];  //used to set the result target.  Do not modify!
int obtainedGridCount[S][S];  //something you may use for the results
Walker walkers[N];

//Helpers
void Lock(std::mutex* m, int  t= VERTEX_SLEEP_TIME)
{
    m->lock();
    std::this_thread::sleep_for(std::chrono::milliseconds(t)); //Sleeps to simulate longer execution time and increase the probability of an issue
}

void Unlock(std::mutex* m)
{
    m->unlock();
}

void CrossTheStreet()
{
    std::this_thread::sleep_for(std::chrono::milliseconds(EDGE_SLEEP_TIME));
} //A dummy function

void WaitAtLocation()
{
    std::this_thread::sleep_for(std::chrono::milliseconds(VERTEX_SLEEP_TIME));
} //A dummy function

void PrintGrid(std::string message, int grid[S][S])
{
    std::cout << message;
    for (int i = 0; i < S; i++)
    {
        for (int j = 0; j < S; j++)
            std::cout << (grid[i][j]<10?"  " : " ") << grid[i][j]; //Initialising grids
        std::cout << "\n";
    }
}

void SetObtainedGrid()
{
    for (int i = 0; i < N; i++) //Setting walkers' final locations
    {
        obtainedGridCount[walkers[i].currentY][walkers[i].currentX]++;
        if (!walkers[i].hasArrived)
        {
            std::cout << "\nAt least one walker has not arrived!\n";
            return;
        }
    }
}

void CompareGrids(int a[S][S], int b[S][S])
{
    for (int i = 0; i < S; i++)
        for (int j = 0; j < S; j++)
            if (a[i][j] != b[i][j])
            {
                std::cout<<"\nError: results are different!\n";
                return;
            }
    std::cout << "\nSeems to be OK!\n";
}


// ####################   Write Most of your code here, except maybe global variables declaration ################################################################

void WalkerI(int id)
{
    //Write your thread code here
}


// ####################   End of your code ################################################################


void InitGame()
{
    for (int i = 0; i < S; i++)
        for (int j = 0; j < S; j++)
            originalGridCount[i][j] = finalGridCount[i][j] = obtainedGridCount[i][j] = 0; //Initialising grids
    for (int i = 0; i < N; i++) //Initialising walkers' locations
    {
        do walkers[i].Init(); 
            while (originalGridCount[walkers[i].currentY][walkers[i].currentX]>= MAX_WALKERS_PER_LOCATION); //repeat init until condition is met
        originalGridCount[walkers[i].currentY][walkers[i].currentX]++;
    }
    for (int i = 0; i < N; i++) //Initialising walkers' locations
        finalGridCount[walkers[i].finalY][walkers[i].finalX]++;
}

int main()
{
    InitGame();
    //Start your threads here.
    PrintGrid("Original locations:\n\n", originalGridCount);
    PrintGrid("\n\nIntended Result:\n\n", finalGridCount);
    SetObtainedGrid();
    PrintGrid("\n\nObtained Result:\n\n", obtainedGridCount);
    CompareGrids(finalGridCount, obtainedGridCount);
}
